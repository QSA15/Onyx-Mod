chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("pistol.obj")};},{urls:["*://krunker.io/models/weapons/weapon_3.obj"]},["blocking"]);
chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("ak.png")};},{urls:["*://krunker.io/textures/weapons/weapon_2.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("ak_e.png")};},{urls:["*://krunker.io/textures/weapons/weapon_2_e.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_3_e.png")};},{urls:["*://krunker.io/textures/weapons/weapon_3_e.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_3.png")};},{urls:["*://krunker.io/textures/weapons/weapon_3.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_3.mp3")};},{urls:["*://krunker.io/sound/weapon_3.mp3"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("pistol.obj")};},{urls:["*://krunker.io/models/weapons/weapon_10.obj"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_3.png")};},{urls:["*://krunker.io/texture/weapons/weapon_10.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_3_e.png")};},{urls:["*://krunker.io/texture/weapons/weapon_10_e.png"]},["blocking"]);