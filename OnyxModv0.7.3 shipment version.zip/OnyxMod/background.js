chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("wep1.obj")};},{urls:["*://krunker.io/models/weapons/weapon_1.obj"]},["blocking"]);
chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_1.png")};},{urls:["*://krunker.io/textures/weapons/weapon_1.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_1_e.png")};},{urls:["*://krunker.io/textures/weapons/weapon_1_e.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_2_e.png")};},{urls:["*://krunker.io/textures/weapons/weapon_2_e.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_2.png")};},{urls:["*://krunker.io/textures/weapons/weapon_2.png"]},["blocking"]);

chrome.webRequest.onBeforeRequest.addListener(function(details){return{redirectUrl:chrome.extension.getURL("weapon_2.obj")};},{urls:["*://krunker.io/models/weapons/weapon_2.obj"]},["blocking"]);
